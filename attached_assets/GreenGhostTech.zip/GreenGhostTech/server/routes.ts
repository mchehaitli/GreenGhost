import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "@db";
import { users, verificationCodes, availability, subscriptions, bookings } from "@db/schema";
import { eq, and, gte, lte, sql, SQL } from "drizzle-orm";
import { addMinutes, startOfDay, endOfDay, addDays } from "date-fns";
import { setupAuth } from "./auth";
import { randomInt } from "crypto";
import type { Request, Response } from 'express';
import { sendEmail, verifyEmailService } from "./services/email";
import OpenAI from "openai";
import * as crypto from 'crypto';
import { z } from 'zod';
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { timingSafeEqual } from 'crypto';

const scryptAsync = promisify(scrypt);

const insertUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  address: z.string().optional(),
  lawnArea: z.number().optional(),
  subscriptionQuote: z.number().optional(),
});

interface CustomerFilter {
  email?: string;
  isVerified?: boolean;
  minLawnArea?: number;
  maxLawnArea?: number;
  fromDate?: Date;
  toDate?: Date;
}

async function getCustomerStats(): Promise<any> {
  return {};
}

async function getCustomers(filter: CustomerFilter): Promise<any[]> {
  const conditions: SQL[] = [eq(users.isAdmin, false)];

  if (filter.email) {
    conditions.push(eq(users.email, filter.email));
  }
  if (filter.isVerified !== undefined) {
    conditions.push(eq(users.emailVerified, filter.isVerified));
  }
  if (filter.minLawnArea !== undefined) {
    conditions.push(sql`CAST(${users.lawnArea} AS NUMERIC) >= ${filter.minLawnArea}`);
  }
  if (filter.maxLawnArea !== undefined) {
    conditions.push(sql`CAST(${users.lawnArea} AS NUMERIC) <= ${filter.maxLawnArea}`);
  }
  if (filter.fromDate !== undefined) {
    conditions.push(gte(users.createdAt, filter.fromDate));
  }
  if (filter.toDate !== undefined) {
    conditions.push(lte(users.createdAt, filter.toDate));
  }

  return db.select()
    .from(users)
    .where(and(...conditions))
    .orderBy(users.createdAt);
}

async function getCustomerById(id: number): Promise<any | null> {
  const customer = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return customer[0] || null;
}

function requireAdmin(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated()) {
    return res.status(401).send("Not authenticated");
  }

  if (!req.user.isAdmin) {
    return res.status(403).send("Not authorized");
  }

  next();
}

export function registerRoutes(app: Express): Server {
  // Set up authentication routes first
  setupAuth(app);

  // Verify email service is working
  verifyEmailService().catch((error) => {
    console.error("Warning: Email service is not properly configured:", error);
  });

  // Request email verification code
  app.post("/api/auth/request-verification", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }

      // Generate a 4-digit code
      const code = generateVerificationCode();
      const expiresAt = addMinutes(new Date(), 15); // Code expires in 15 minutes

      // Store the code
      await db.insert(verificationCodes).values({
        email,
        code,
        expiresAt,
      });

      // Try to send verification email, but don't block registration if it fails
      try {
        const emailResult = await sendEmail(email, "verificationCode", { code, email });
        if (!emailResult.success) {
          console.warn("Failed to send verification email:", emailResult.error);
        }
      } catch (emailError) {
        console.warn("Email sending failed:", emailError);
      }

      // Return the code in development environment for testing
      const codeResponse = process.env.NODE_ENV === 'production'
        ? { message: "Verification code sent" }
        : { message: "Verification code sent", code };

      res.json(codeResponse);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Verify email code
  app.post("/api/auth/verify-code", async (req:Request, res:Response) => {
    try {
      const { email, code } = req.body;
      if (!email || !code) {
        return res.status(400).send("Email and code are required");
      }

      const [verificationCode] = await db
        .select()
        .from(verificationCodes)
        .where(
          and(
            eq(verificationCodes.email, email),
            eq(verificationCodes.code, code),
            gte(verificationCodes.expiresAt, new Date())
          )
        )
        .limit(1);

      if (!verificationCode) {
        return res.status(400).send("Invalid or expired verification code");
      }

      // Mark the user's email as verified if they exist
      await db
        .update(users)
        .set({ emailVerified: true })
        .where(eq(users.email, email));

      // Delete used verification code
      await db
        .delete(verificationCodes)
        .where(eq(verificationCodes.id, verificationCode.id));

      res.json({ message: "Email verified successfully" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get available time slots for next 7 days
  app.get("/api/availability", async (_req:Request, res:Response) => {
    const start = startOfDay(new Date());
    const end = endOfDay(addDays(start, 7));

    const slots = await db.select()
      .from(availability)
      .where(
        and(
          gte(availability.timeSlot, start),
          lte(availability.timeSlot, end),
          sql`${availability.capacity} > ${availability.bookedCount}`
        )
      )
      .orderBy(availability.timeSlot);

    res.json(slots);
  });

  // Get available subscriptions
  app.get("/api/subscriptions", async (_req:Request, res:Response) => {
    const results = await db.select().from(subscriptions);
    res.json(results);
  });

  // Get user's bookings with maintenance status
  app.get("/api/bookings", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Not authenticated");
    }

    try {
      const results = await db.select()
        .from(bookings)
        .where(eq(bookings.userId, req.user.id))
        .orderBy(sql`${bookings.serviceDate} DESC`);

      // Add status based on service date
      const bookingsWithStatus = results.map(booking => ({
        ...booking,
        status: new Date(booking.serviceDate) < new Date()
          ? 'completed'
          : 'scheduled'
      }));

      res.json(bookingsWithStatus);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create a new booking
  app.post("/api/bookings", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Not authenticated");
    }

    try {
      // Start a transaction
      const result = await db.transaction(async (tx) => {
        // Get availability
        const slot = await tx.query.availability.findFirst({
          where: eq(availability.id, req.body.availabilityId)
        });

        if (!slot || slot.bookedCount >= slot.capacity) {
          throw new Error("Time slot not available");
        }

        // Get subscription details
        const [subscription] = await tx
          .select()
          .from(subscriptions)
          .where(eq(subscriptions.id, req.body.subscriptionId));

        if (!subscription) {
          throw new Error("Invalid subscription plan");
        }

        // Update availability
        await tx
          .update(availability)
          .set({ bookedCount: sql`${availability.bookedCount} + 1` })
          .where(eq(availability.id, req.body.availabilityId));

        // Create booking
        const [booking] = await tx
          .insert(bookings)
          .values({
            ...req.body,
            userId: req.user.id,
            serviceDate: slot.timeSlot
          })
          .returning();

        // Send confirmation email
        await sendEmail(req.user.email, "bookingConfirmation", {
          customerName: req.body.customerName,
          serviceDate: slot.timeSlot,
          address: req.body.address,
          subscriptionPlan: subscription.name,
        });

        return booking;
      });

      res.json(result);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid booking data" });
    }
  });

  // Get booking by ID
  app.get("/api/bookings/:id", async (req:Request, res:Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Not authenticated");
    }

    const result = await db
      .select()
      .from(bookings)
      .where(
        and(
          eq(bookings.id, parseInt(req.params.id)),
          eq(bookings.userId, req.user.id)
        )
      );

    if (result.length === 0) {
      res.status(404).json({ error: "Booking not found" });
    } else {
      res.json(result[0]);
    }
  });

  // Test email endpoint
  app.post("/api/test-email", async (req: Request, res: Response) => {
    try {
      const { to } = req.body;

      if (!to) {
        return res.status(400).send("Email address is required");
      }

      console.log("Attempting to send test email to:", to);

      const result = await sendEmail(to, "test", {
        subject: "Test Email from Green Ghost",
        message: "This is a test email to verify the email service functionality."
      });

      if (!result.success) {
        throw new Error(result.error);
      }

      console.log("Test email sent successfully");
      res.json({ message: "Test email sent successfully" });
    } catch (error: any) {
      console.error("Failed to send test email:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Chat endpoint for AI assistant
  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const { message } = req.body;

      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({
          message: "OpenAI API key not configured"
        });
      }

      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant for a lawn care company. Provide concise, accurate information about lawn care services, maintenance tips, and scheduling assistance.",
          },
          { role: "user", content: message },
        ],
      });

      const aiResponse = completion.choices[0]?.message?.content ||
        "I apologize, but I couldn't process your request at the moment.";

      res.json({ message: aiResponse });
    } catch (error: any) {
      console.error("Chat API Error:", error);
      res.status(500).json({
        message: "An error occurred while processing your message"
      });
    }
  });


  // Admin login endpoint
  app.post("/api/admin/login", async (req: Request, res: Response, next) => {
    try {
      const { email, password } = req.body;

      // Find admin user
      const [admin] = await db
        .select()
        .from(users)
        .where(
          and(
            eq(users.email, email),
            eq(users.isAdmin, true)
          )
        )
        .limit(1);

      if (!admin) {
        return res.status(401).send("Invalid credentials");
      }

      // Verify password
      const [hashedPassword, salt] = admin.password.split(".");
      const hashedPasswordBuf = Buffer.from(hashedPassword, "hex");
      const suppliedPasswordBuf = (await scryptAsync(
        password,
        salt,
        64
      )) as Buffer;

      const isMatch = timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf);
      if (!isMatch) {
        return res.status(401).send("Invalid credentials");
      }

      // Log the admin in
      req.login(admin, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({ message: "Login successful" });
      });
    } catch (error: any) {
      next(error);
    }
  });

  // Get customer statistics
  app.get("/api/customers/stats", requireAdmin, async (req: Request, res: Response) => {
    try {
      const stats = await getCustomerStats();
      res.json(stats);
    } catch (error: any) {
      console.error("Error fetching customer stats:", error);
      res.status(500).json({ error: "Failed to fetch customer statistics" });
    }
  });

  // Get filtered customers
  app.get("/api/customers/filter", requireAdmin, async (req: Request, res: Response) => {
    try {
      const filter: CustomerFilter = {
        email: req.query.email as string | undefined,
        isVerified: req.query.verified === 'true' ? true :
                    req.query.verified === 'false' ? false : undefined,
        minLawnArea: req.query.minLawnArea ? Number(req.query.minLawnArea) : undefined,
        maxLawnArea: req.query.maxLawnArea ? Number(req.query.maxLawnArea) : undefined,
        fromDate: req.query.fromDate ? new Date(req.query.fromDate as string) : undefined,
        toDate: req.query.toDate ? new Date(req.query.toDate as string) : undefined,
      };

      const customers = await getCustomers(filter);
      res.json(customers);
    } catch (error: any) {
      console.error("Error fetching filtered customers:", error);
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  // Get specific customer by ID
  app.get("/api/customers/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const customer = await getCustomerById(Number(req.params.id));
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error: any) {
      console.error("Error fetching customer:", error);
      res.status(500).json({ error: "Failed to fetch customer" });
    }
  });

  app.get("/api/customers", requireAdmin, async (req: Request, res: Response) => {
    try {
      const customers = await db
        .select({
          id: users.id,
          email: users.email,
          address: users.address,
          lawn_area: sql`CAST(${users.lawnArea} AS FLOAT)`,
          subscription_quote: sql`CAST(${users.subscriptionQuote} AS FLOAT)`,
          email_verified: users.emailVerified,
          created_at: users.createdAt,
        })
        .from(users)
        .where(eq(users.isAdmin, false))
        .orderBy(users.createdAt);

      res.json(customers);
    } catch (error: any) {
      console.error("Error fetching customers:", error);
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  app.delete("/api/customers/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);

      // Check if user exists
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Delete the user
      await db
        .delete(users)
        .where(eq(users.id, userId));

      res.json({ message: "User deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  app.patch("/api/customers/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { email, address, lawn_area, password } = req.body;

      // Check if user exists
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Prepare update data
      const updateData: any = {
        email,
        address,
        lawnArea: lawn_area ? sql`CAST(${lawn_area} AS DECIMAL)` : null,
      };

      // If password is provided, hash it
      if (password) {
        const salt = randomBytes(16).toString('hex');
        const buf = await scryptAsync(password, salt, 64) as Buffer;
        updateData.password = `${buf.toString('hex')}.${salt}`;
      }

      // Update the user
      await db
        .update(users)
        .set(updateData)
        .where(eq(users.id, userId));

      res.json({ message: "User updated successfully" });
    } catch (error: any) {
      console.error("Error updating user:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  app.post("/api/register", async (req: Request, res: Response, next) => {
    try {
      // Log incoming registration data (excluding sensitive information)
      console.log("Registration attempt:", {
        email: req.body.email,
        hasAddress: !!req.body.address,
        hasLawnArea: !!req.body.lawnArea,
        hasQuote: !!req.body.subscriptionQuote
      });

      const result = insertUserSchema.safeParse(req.body);
      if (!result.success) {
        console.log("Validation failed:", result.error.issues);
        return res
          .status(400)
          .send("Invalid input: " + result.error.issues.map(i => i.message).join(", "));
      }

      const { email, password } = result.data;

      // Check if user already exists
      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      if (existingUser) {
        return res.status(400).send("Email already registered");
      }

      // Generate a salt and hash the password
      const salt = randomBytes(16).toString('hex');
      const buf = await scryptAsync(password, salt, 64) as Buffer;
      const hashedPassword = `${buf.toString('hex')}.${salt}`;

      // Create the new user
      const [newUser] = await db
        .insert(users)
        .values({
          email: result.data.email,
          password: hashedPassword,
          address: result.data.address ?? null,
          lawnArea: result.data.lawnArea ? sql`CAST(${result.data.lawnArea} AS DECIMAL)` : null,
          subscriptionQuote: result.data.subscriptionQuote ? sql`CAST(${result.data.subscriptionQuote} AS DECIMAL)` : null,
          emailVerified: false,
          isAdmin: false,
        })
        .returning();

      console.log("User registered successfully:", {
        id: newUser.id,
        email: newUser.email,
        hasAddress: !!newUser.address,
        hasLawnArea: !!newUser.lawnArea,
        hasQuote: !!newUser.subscriptionQuote
      });

      // Log the user in after registration
      req.login(newUser, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({
          message: "Registration successful",
          user: { id: newUser.id, email: newUser.email },
        });
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateVerificationCode(): string {
  return randomInt(1000, 10000).toString().padStart(4, '0');
}