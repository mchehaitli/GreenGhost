import OpenAI from "openai";
import type { ChatCompletionMessageParam } from "openai/resources/chat/completions";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY is required");
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const SYSTEM_PROMPT = `You are an AI customer service assistant for Green Ghost, a robotic landscaping company that provides automated lawn and pool maintenance services.

Your responsibilities:
1. Answer questions about our services, pricing, and booking process
2. Help troubleshoot common issues with the robotic lawn mowers and pool cleaners
3. Provide basic lawn care and pool maintenance advice
4. Assist with account and booking-related queries

Keep responses friendly, professional, and focused on lawn care and pool maintenance. If you can't help with a specific issue, offer to escalate to human support.`;

export async function generateChatResponse(userMessage: string, chatHistory: ChatCompletionMessageParam[] = []): Promise<string> {
  try {
    const messages: ChatCompletionMessageParam[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...chatHistory,
      { role: "user", content: userMessage }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages,
      temperature: 0.7,
      max_tokens: 500,
    });

    return response.choices[0].message.content || "I apologize, but I'm unable to provide a response at the moment. Please try again or contact our human support team.";
  } catch (error: any) {
    console.error("Error generating chat response:", error);
    throw new Error("Failed to generate response");
  }
}
