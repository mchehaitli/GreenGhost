import nodemailer from "nodemailer";
import { format } from "date-fns";

// Initialize nodemailer transporter with development fallback
const transporter = process.env.NODE_ENV === 'production'
  ? nodemailer.createTransport({
      host: "smtp-relay.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
      logger: true,
      debug: process.env.NODE_ENV !== 'production',
    })
  : nodemailer.createTransport({
      host: "localhost",
      port: 1025,
      secure: false,
      auth: {
        user: "test",
        pass: "test",
      },
      tls: {
        rejectUnauthorized: false
      }
    });

// Email templates
const templates = {
  test: (data: { subject: string; message: string }) => ({
    subject: data.subject,
    from: {
      name: 'Green Ghost Support',
      address: process.env.SMTP_USER!
    },
    sender: `"Green Ghost Support" <${process.env.SMTP_USER!}>`,
    headers: {
      'X-Entity-Ref-ID': 'support',
      'Sender': `"Green Ghost Support" <${process.env.SMTP_USER!}>`,
    },
    html: `
      <h1>Test Email</h1>
      <p>${data.message}</p>
      <p>Sent at: ${format(new Date(), 'PPpp')}</p>
    `,
  }),

  bookingConfirmation: (data: {
    customerName: string;
    serviceDate: Date;
    address: string;
    subscriptionPlan: string;
  }) => ({
    subject: "Green Ghost: Booking Confirmation",
    from: {
      name: 'Green Ghost Bookings',
      address: process.env.SMTP_USER!
    },
    sender: `"Green Ghost Bookings" <${process.env.SMTP_USER!}>`,
    headers: {
      'X-Entity-Ref-ID': 'bookings',
      'Sender': `"Green Ghost Bookings" <${process.env.SMTP_USER!}>`,
    },
    html: `
      <h1>Booking Confirmation</h1>
      <p>Dear ${data.customerName},</p>
      <p>Thank you for choosing Green Ghost for your lawn care needs. Your booking has been confirmed:</p>
      <ul>
        <li>Service Date: ${format(data.serviceDate, "PPP 'at' p")}</li>
        <li>Service Address: ${data.address}</li>
        <li>Service Plan: ${data.subscriptionPlan}</li>
      </ul>
      <p>If you need to make any changes to your booking, please log in to your account or contact our support team.</p>
      <p>Best regards,<br>The Green Ghost Team</p>
    `,
  }),

  verificationCode: (data: { code: string; email: string }) => ({
    subject: "Green Ghost: Email Verification Code",
    from: {
      name: 'Green Ghost Verification',
      address: process.env.SMTP_USER!
    },
    sender: `"Green Ghost Verification" <${process.env.SMTP_USER!}>`,
    headers: {
      'X-Entity-Ref-ID': 'verification',
      'Sender': `"Green Ghost Verification" <${process.env.SMTP_USER!}>`,
    },
    html: `
      <h1>Email Verification</h1>
      <p>Your verification code is: <strong>${data.code}</strong></p>
      <p>This code will expire in 15 minutes.</p>
      <p>If you didn't request this code, please ignore this email.</p>
    `,
  }),

  serviceReminder: (data: {
    customerName: string;
    serviceDate: Date;
    address: string;
  }) => ({
    subject: "Green Ghost: Upcoming Service Reminder",
    from: {
      name: 'Green Ghost Reminders',
      address: process.env.SMTP_USER!
    },
    sender: `"Green Ghost Reminders" <${process.env.SMTP_USER!}>`,
    headers: {
      'X-Entity-Ref-ID': 'reminders',
      'Sender': `"Green Ghost Reminders" <${process.env.SMTP_USER!}>`,
    },
    html: `
      <h1>Service Reminder</h1>
      <p>Dear ${data.customerName},</p>
      <p>This is a friendly reminder about your upcoming lawn care service:</p>
      <ul>
        <li>Date: ${format(data.serviceDate, "PPP 'at' p")}</li>
        <li>Address: ${data.address}</li>
      </ul>
      <p>Please ensure your lawn is accessible for our robotic service team.</p>
      <p>Best regards,<br>The Green Ghost Team</p>
    `,
  }),
};

export async function sendEmail(to: string, template: keyof typeof templates, data: any) {
  try {
    const emailConfig = templates[template](data);

    // In development, just log the email and return success
    if (process.env.NODE_ENV !== 'production') {
      console.log('Development Mode - Email would be sent:', {
        to,
        ...emailConfig,
        data
      });
      return { success: true };
    }

    const result = await transporter.sendMail({
      ...emailConfig,
      to,
      from: {
        name: 'Green Ghost',
        address: process.env.SMTP_USER || 'noreply@greenghosttech.com',
      },
      messageId: `${Date.now()}.${Math.random().toString(36).substring(2)}@greenghosttech.com`,
      encoding: 'UTF-8',
      textEncoding: 'base64',
      priority: 'normal',
      headers: {
        ...emailConfig.headers,
        'Content-Type': 'text/html; charset=utf-8',
        'MIME-Version': '1.0',
      }
    });

    console.log('Email sent successfully:', result.messageId);
    return { success: true };
  } catch (error: any) {
    console.error("Failed to send email:", error);
    // Return success in development even if email fails
    if (process.env.NODE_ENV !== 'production') {
      console.log('Development Mode - Continuing despite email error');
      return { success: true };
    }
    return { success: false, error: error.message };
  }
}

export async function verifyEmailService() {
  try {
    // In development, skip actual verification
    if (process.env.NODE_ENV !== 'production') {
      console.log('Development Mode - Email service verification skipped');
      return true;
    }

    await transporter.verify();
    console.log("Email service verification successful");
    return true;
  } catch (error) {
    console.error("Email service verification failed:", error);
    // Don't throw in development
    if (process.env.NODE_ENV !== 'production') {
      return true;
    }
    return false;
  }
}