import { db } from "@db";
import { users } from "@db/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import type { SQL } from "drizzle-orm";

export interface CustomerFilter {
  email?: string;
  isVerified?: boolean;
  minLawnArea?: number;
  maxLawnArea?: number;
  fromDate?: Date;
  toDate?: Date;
}

export interface CustomerStats {
  totalCustomers: number;
  verifiedCustomers: number;
  averageLawnArea: number;
  averageQuote: number;
}

export async function getCustomers(filter?: CustomerFilter) {
  const conditions: SQL[] = [];

  if (filter?.email) {
    conditions.push(eq(users.email, filter.email));
  }

  if (filter?.isVerified !== undefined) {
    conditions.push(eq(users.emailVerified, filter.isVerified));
  }

  if (filter?.minLawnArea !== undefined) {
    conditions.push(sql`CAST(${users.lawnArea} AS NUMERIC) >= ${filter.minLawnArea}`);
  }

  if (filter?.maxLawnArea !== undefined) {
    conditions.push(sql`CAST(${users.lawnArea} AS NUMERIC) <= ${filter.maxLawnArea}`);
  }

  if (filter?.fromDate) {
    conditions.push(gte(users.createdAt, filter.fromDate));
  }

  if (filter?.toDate) {
    conditions.push(lte(users.createdAt, filter.toDate));
  }

  const query = conditions.length > 0
    ? db.select().from(users).where(and(...conditions))
    : db.select().from(users);

  return query.orderBy(users.createdAt);
}

export async function getCustomerStats(): Promise<CustomerStats> {
  const result = await db.select({
    totalCustomers: sql<number>`CAST(COUNT(*) AS INTEGER)`,
    verifiedCustomers: sql<number>`CAST(COUNT(CASE WHEN ${users.emailVerified} = true THEN 1 END) AS INTEGER)`,
    averageLawnArea: sql<number>`COALESCE(AVG(CAST(${users.lawnArea} AS NUMERIC)), 0)`,
    averageQuote: sql<number>`COALESCE(AVG(CAST(${users.subscriptionQuote} AS NUMERIC)), 0)`,
  }).from(users);

  return {
    totalCustomers: result[0].totalCustomers,
    verifiedCustomers: result[0].verifiedCustomers,
    averageLawnArea: result[0].averageLawnArea,
    averageQuote: result[0].averageQuote,
  };
}

export async function getCustomerById(id: number) {
  const [customer] = await db
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);

  return customer;
}