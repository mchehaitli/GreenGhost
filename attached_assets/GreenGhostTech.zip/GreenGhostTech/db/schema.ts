import { pgTable, text, serial, timestamp, decimal, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  address: text("address"),
  lawnArea: decimal("lawn_area", { precision: 10, scale: 2 }),
  subscriptionQuote: decimal("subscription_quote", { precision: 10, scale: 2 }),
  emailVerified: boolean("email_verified").default(false).notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const verificationCodes = pgTable("verification_codes", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: decimal("price").notNull(),
  interval: text("interval").notNull(),
});

export const availability = pgTable("availability", {
  id: serial("id").primaryKey(),
  timeSlot: timestamp("time_slot").notNull(),
  capacity: integer("capacity").notNull().default(3),
  bookedCount: integer("booked_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  serviceDate: timestamp("service_date").notNull(),
  address: text("address").notNull(),
  notes: text("notes"),
  subscriptionId: integer("subscription_id").references(() => subscriptions.id),
  availabilityId: integer("availability_id").references(() => availability.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users, {
  email: z.string().email("Invalid email address"),
  address: z.string().min(5, "Please enter a valid address").optional(),
  lawnArea: z.number().positive("Lawn area must be greater than 0").optional(),
  subscriptionQuote: z.number().positive("Subscription quote must be greater than 0").optional(),
});

export const selectUserSchema = createSelectSchema(users);
export type InsertUser = typeof users.$inferInsert;
export type SelectUser = typeof users.$inferSelect;

export const insertBookingSchema = createInsertSchema(bookings);
export const selectBookingSchema = createSelectSchema(bookings);
export type InsertBooking = typeof bookings.$inferInsert;
export type SelectBooking = typeof bookings.$inferSelect;

export const insertSubscriptionSchema = createInsertSchema(subscriptions);
export const selectSubscriptionSchema = createSelectSchema(subscriptions);
export type InsertSubscription = typeof subscriptions.$inferInsert;
export type SelectSubscription = typeof subscriptions.$inferSelect;

export const insertAvailabilitySchema = createInsertSchema(availability);
export const selectAvailabilitySchema = createSelectSchema(availability);
export type InsertAvailability = typeof availability.$inferInsert;
export type SelectAvailability = typeof availability.$inferSelect;