import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen from './screens/HomeScreen';
import BookingScreen from './screens/BookingScreen';
import ServicesScreen from './screens/ServicesScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator 
          initialRouteName="Home"
          screenOptions={{
            headerStyle: {
              backgroundColor: '#22C55E',
            },
            headerTintColor: '#fff',
          }}
        >
          <Stack.Screen 
            name="Home" 
            component={HomeScreen}
            options={{ title: 'Green Ghost' }}
          />
          <Stack.Screen 
            name="Booking" 
            component={BookingScreen}
            options={{ title: 'Schedule Service' }}
          />
          <Stack.Screen 
            name="Services" 
            component={ServicesScreen}
            options={{ title: 'Our Services' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
