import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Download, LogIn, UserCircle } from "lucide-react";
import { useUser } from "@/hooks/use-user";

export default function NavigationBar() {
  const { user, logout } = useUser();

  return (
    <nav className="fixed w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/">
            <Button variant="link" className="flex items-center space-x-2 px-0">
              <img src="/ghost-logo.svg" alt="Green Ghost" className="h-8 w-8" />
              <span className="font-bold text-lg">Green Ghost</span>
            </Button>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
          <nav className="flex items-center space-x-6">
            <Link href="/services">
              <Button variant="ghost">Services</Button>
            </Link>
            <Link href="/download">
              <Button variant="outline" className="gap-2 hidden md:flex">
                <Download className="h-4 w-4" />
                Get Mobile App
              </Button>
            </Link>
            {user ? (
              <>
                <Link href="/dashboard">
                  <Button variant="outline" className="gap-2">
                    <UserCircle className="h-4 w-4" />
                    Dashboard
                  </Button>
                </Link>
                <Button 
                  variant="ghost" 
                  onClick={() => logout()}
                >
                  Logout
                </Button>
              </>
            ) : (
              <Link href="/auth">
                <Button variant="outline" className="gap-2">
                  <LogIn className="h-4 w-4" />
                  Login
                </Button>
              </Link>
            )}
          </nav>
        </div>
      </div>
    </nav>
  );
}