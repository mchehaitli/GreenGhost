import { useRef, useEffect, useState, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { useLoadScript } from "@react-google-maps/api";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { debounce } from "lodash";

const libraries: ("places")[] = ["places"];

interface Props {
  value?: string;
  onChange: (value: string, isValid?: boolean) => void;
  className?: string;
  placeholder?: string;
  name?: string;
  onBlur?: () => void;
  disabled?: boolean;
}

interface FormattedAddress {
  street_number?: string;
  route?: string;
  locality?: string;
  administrative_area_level_1?: string;
  postal_code?: string;
  country?: string;
}

export function AddressInput({ value = "", onChange, className, placeholder, onBlur, name, disabled }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [localValue, setLocalValue] = useState<string>("");
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isValidAddress, setIsValidAddress] = useState<boolean>(false);
  const [isUsingFallback, setIsUsingFallback] = useState(false);
  const [dropdownDimensions, setDropdownDimensions] = useState({
    width: 0,
    left: 0,
    top: 0
  });

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY ?? "",
    libraries,
  });

  // Basic US address validation regex (fallback)
  const addressRegex = /^\d+\s+[A-Za-z0-9\s.-]+,\s*[A-Za-z\s]+,\s*[A-Z]{2}\s*\d{5}(-\d{4})?$/;

  // Update dropdown position
  const updateDropdownPosition = useCallback(() => {
    if (!inputRef.current || disabled) return;

    const rect = inputRef.current.getBoundingClientRect();
    setDropdownDimensions({
      width: rect.width,
      left: rect.left,
      top: rect.bottom + window.scrollY + 5
    });
  }, [disabled]);

  // Initialize local state with prop value
  useEffect(() => {
    if (value !== localValue) {
      setLocalValue(value);
      setIsValidAddress(false);
    }
  }, [value]);

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;

    const newValue = e.target.value;
    setLocalValue(newValue);

    if (isUsingFallback) {
      const isValid = addressRegex.test(newValue);
      setIsValidAddress(isValid);
      onChange(newValue, isValid);

      if (newValue.length > 0 && !isValid) {
        setError("Please enter a complete address (e.g., 123 Main St, City, ST 12345)");
      } else {
        setError(null);
      }
    } else {
      setIsValidAddress(false);
      onChange(newValue, false);
      setError(null);
    }
  };

  // Initialize Places API
  useEffect(() => {
    if (!isLoaded || !inputRef.current || loadError || disabled) {
      setIsUsingFallback(true);
      return;
    }

    try {
      setIsInitializing(true);
      const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
        types: ["address"],
        componentRestrictions: { country: "us" },
        fields: ["address_components", "formatted_address"],
      });

      autocomplete.addListener("place_changed", () => {
        const place = autocomplete.getPlace();
        if (!place.address_components) {
          setError("Please select a valid address from the suggestions");
          return;
        }

        const formatted: FormattedAddress = {};
        place.address_components.forEach(component => {
          const type = component.types[0];
          if (type in formatted) {
            formatted[type as keyof FormattedAddress] = component.short_name;
          }
        });

        const addressString = place.formatted_address || [
          `${formatted.street_number} ${formatted.route}`,
          `${formatted.locality}, ${formatted.administrative_area_level_1} ${formatted.postal_code}`
        ].filter(Boolean).join(', ');

        setLocalValue(addressString);
        setIsValidAddress(true);
        onChange(addressString, true);
        setError(null);
      });

      updateDropdownPosition();

      const debouncedUpdatePosition = debounce(updateDropdownPosition, 100);
      window.addEventListener('resize', debouncedUpdatePosition);
      window.addEventListener('scroll', debouncedUpdatePosition);

      setIsInitializing(false);
      setIsUsingFallback(false);

      return () => {
        window.removeEventListener('resize', debouncedUpdatePosition);
        window.removeEventListener('scroll', debouncedUpdatePosition);
        google.maps.event.clearInstanceListeners(autocomplete);
      };
    } catch (error) {
      console.error("Failed to initialize Places API:", error);
      setIsUsingFallback(true);
      setIsInitializing(false);
      setError("Address suggestions are currently unavailable. Using basic validation.");
    }
  }, [isLoaded, loadError, disabled]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <Input
          ref={inputRef}
          type="text"
          value={localValue}
          onChange={handleInputChange}
          onBlur={onBlur}
          className={`${className} ${isValidAddress ? 'border-green-500' : ''}`}
          placeholder={placeholder || "Enter your address (e.g., 123 Main St, City, ST 12345)"}
          name={name}
          disabled={disabled}
          autoComplete="street-address"
        />
        {isInitializing && !disabled && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </div>
        )}
      </div>
      {error && !disabled && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {isUsingFallback && !disabled && (
        <Alert>
          <AlertDescription>
            Using basic address validation. For address suggestions, please ensure Google Maps API is properly configured.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}