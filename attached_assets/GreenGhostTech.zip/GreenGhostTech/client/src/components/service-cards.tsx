import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Bot, Droplets, Clock } from "lucide-react";

const services = [
  {
    title: "Automated Lawn Mowing",
    description: "Precision cutting with robotic mowers for a perfect lawn every time",
    icon: Bot,
    image: "/images/robot-mower.jpg",
  },
  {
    title: "Smart Irrigation",
    description: "Water-efficient systems that adapt to weather conditions",
    icon: Droplets,
    image: "/images/smart-irrigation.jpg",
  },
  {
    title: "Scheduled Maintenance",
    description: "Regular automated maintenance to keep your lawn looking its best",
    icon: Clock,
    image: "/images/scheduled-maintenance.jpg",
  },
];

export default function ServiceCards() {
  return (
    <section className="py-12 bg-muted/50">
      <div className="container px-4 mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.title}>
              <CardHeader>
                <service.icon className="h-10 w-10 text-primary mb-4" />
                <CardTitle>{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-48 bg-muted rounded-lg flex items-center justify-center">
                  <service.icon className="h-20 w-20 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}