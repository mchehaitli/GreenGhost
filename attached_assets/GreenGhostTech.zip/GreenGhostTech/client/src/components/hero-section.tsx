import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Bot } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative pt-24 pb-12 overflow-hidden">
      <div className="container px-4 mx-auto">
        <div className="flex flex-wrap items-center -mx-4">
          <div className="w-full lg:w-1/2 px-4 mb-12 lg:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              The Future of Lawn Care is{" "}
              <span className="text-primary">Automated</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Experience premium lawn care with our robotic equipment. Quieter,
              cleaner, and more efficient than traditional methods.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/auth">
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href="/services">
                <Button variant="outline" size="lg">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
          <div className="w-full lg:w-1/2 px-4">
            <div className="bg-muted rounded-lg p-12 flex items-center justify-center">
              <Bot className="h-48 w-48 text-primary" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}