import * as React from "react"

interface InputOTPProps {
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
  disabled?: boolean;  // Added disabled prop
}

export const InputOTP = React.forwardRef<HTMLDivElement, InputOTPProps>(
  ({ value = "", onChange, maxLength = 4, disabled = false }, ref) => {
    const inputRefs = React.useRef<(HTMLInputElement | null)[]>([]);

    // Clear inputs on unmount
    React.useEffect(() => {
      return () => {
        inputRefs.current.forEach(input => {
          if (input) input.value = '';
        });
      };
    }, []);

    const focusInput = (index: number) => {
      if (!disabled && index >= 0 && index < maxLength) {
        inputRefs.current[index]?.focus();
      }
    };

    const handleInput = (index: number, inputValue: string) => {
      if (disabled) return;

      const newValue = value.split('');
      newValue[index] = inputValue.slice(-1);
      const combinedValue = newValue.join('');
      onChange(combinedValue);

      if (inputValue && index < maxLength - 1) {
        focusInput(index + 1);
      }
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
      if (disabled) return;

      if (e.key === 'Backspace' && !value[index] && index > 0) {
        focusInput(index - 1);
      }
    };

    return (
      <div ref={ref} className="flex gap-2">
        {Array.from({ length: maxLength }).map((_, index) => (
          <input
            key={index}
            ref={el => inputRefs.current[index] = el}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={1}
            value={value[index] || ''}
            onChange={e => handleInput(index, e.target.value)}
            onKeyDown={e => handleKeyDown(index, e)}
            className={`h-10 w-10 text-center border rounded text-lg 
              ${disabled ? 'bg-muted cursor-not-allowed' : 'bg-background'} 
              text-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1`}
            autoComplete="off"
            autoCorrect="off"
            spellCheck="false"
            aria-label={`Digit ${index + 1}`}
            disabled={disabled}
          />
        ))}
      </div>
    );
  }
);

InputOTP.displayName = "InputOTP";