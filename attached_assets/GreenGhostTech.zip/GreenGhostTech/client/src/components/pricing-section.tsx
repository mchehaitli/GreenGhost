import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Check } from "lucide-react";
import { Link } from "wouter";

const plans = [
  {
    name: "Basic",
    price: "99",
    description: "Perfect for small yards",
    features: [
      "Bi-weekly mowing",
      "Edge trimming",
      "Clipping removal",
      "Basic scheduling",
    ],
  },
  {
    name: "Premium",
    price: "199",
    description: "Most popular for medium yards",
    features: [
      "Weekly mowing",
      "Edge trimming",
      "Clipping removal",
      "Priority scheduling",
      "Fertilization",
      "Weed control",
    ],
  },
  {
    name: "Ultimate",
    price: "299",
    description: "Complete care for large yards",
    features: [
      "Weekly mowing",
      "Edge trimming",
      "Clipping removal",
      "Priority scheduling",
      "Fertilization",
      "Weed control",
      "Smart irrigation",
      "Seasonal cleanup",
    ],
  },
];

export default function PricingSection() {
  return (
    <section className="py-12">
      <div className="container px-4 mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">
          Simple, Transparent Pricing
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Card key={plan.name} className="flex flex-col">
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <ul className="space-y-2">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="h-4 w-4 text-primary mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="mt-6">
                  <Link href="/book">
                    <Button className="w-full">Get Started</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
