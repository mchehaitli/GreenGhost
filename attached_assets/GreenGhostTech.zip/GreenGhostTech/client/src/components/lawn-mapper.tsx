import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Ruler, Square, Undo } from "lucide-react";

interface Point {
  x: number;
  y: number;
}

interface Props {
  onAreaChange?: (area: number) => void;
}

export default function LawnMapper({ onAreaChange }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<Point[]>([]);
  const [area, setArea] = useState<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear and redraw
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#22c55e20";
    ctx.strokeStyle = "#22c55e";
    ctx.lineWidth = 2;

    // Draw the polygon
    if (points.length > 0) {
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      points.forEach((point) => {
        ctx.lineTo(point.x, point.y);
      });
      if (points.length > 2) {
        ctx.closePath();
        ctx.fill();
      }
      ctx.stroke();
    }

    // Draw points
    points.forEach((point) => {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = "#22c55e";
      ctx.fill();
    });
  }, [points]);

  useEffect(() => {
    if (points.length > 2) {
      // Calculate area using shoelace formula
      let area = 0;
      for (let i = 0; i < points.length; i++) {
        const j = (i + 1) % points.length;
        area += points[i].x * points[j].y;
        area -= points[j].x * points[i].y;
      }
      area = Math.abs(area) / 2;
      // Convert to square feet (assuming 1px = 1ft for now)
      const areaInSqFt = Math.round(area);
      setArea(areaInSqFt);
      // Ensure we're passing a number to the parent component
      if (onAreaChange && !isNaN(areaInSqFt) && areaInSqFt > 0) {
        onAreaChange(areaInSqFt);
      }
    } else {
      setArea(0);
      if (onAreaChange) {
        onAreaChange(0);
      }
    }
  }, [points, onAreaChange]);

  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    setPoints([...points, { x, y }]);
  };

  const handleUndo = () => {
    setPoints(points.slice(0, -1));
  };

  const handleReset = () => {
    setPoints([]);
    setArea(0);
    if (onAreaChange) {
      onAreaChange(0);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Square className="h-5 w-5" />
          Lawn Map
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative border rounded-lg overflow-hidden">
            <canvas
              ref={canvasRef}
              width={400}
              height={300}
              onClick={handleCanvasClick}
              className="bg-muted/50 cursor-crosshair"
            />
            {points.length > 0 && (
              <div className="absolute top-2 right-2 space-x-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleUndo}
                  className="gap-1"
                >
                  <Undo className="h-4 w-4" />
                  Undo
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleReset}
                  className="gap-1"
                >
                  Reset
                </Button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 text-sm">
            <Ruler className="h-4 w-4" />
            <span>
              Approximate Area:{" "}
              <strong>{area > 0 ? `${area} sq ft` : "Draw your lawn"}</strong>
            </span>
          </div>

          <p className="text-sm text-muted-foreground">
            Click to add points and create an outline of your lawn. This helps us
            provide more accurate service estimates.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}