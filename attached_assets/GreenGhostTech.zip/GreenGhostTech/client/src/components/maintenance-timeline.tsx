import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Clock, AlertCircle } from "lucide-react";
import { format } from "date-fns";

interface MaintenanceEvent {
  id: number;
  serviceDate: string;
  status: 'completed' | 'scheduled' | 'missed';
  description: string;
}

interface MaintenanceTimelineProps {
  events: MaintenanceEvent[];
}

export default function MaintenanceTimeline({ events }: MaintenanceTimelineProps) {
  const getStatusIcon = (status: MaintenanceEvent['status']) => {
    switch (status) {
      case 'completed':
        return <Check className="h-5 w-5 text-green-500" />;
      case 'scheduled':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'missed':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {events.map((event, index) => (
        <motion.div
          key={event.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <div className="mt-1">
                  {getStatusIcon(event.status)}
                </div>
                <div className="flex-1">
                  <p className="font-medium">
                    {format(new Date(event.serviceDate), "PPP")}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {event.description}
                  </p>
                </div>
                <div className="text-sm text-muted-foreground">
                  {format(new Date(event.serviceDate), "p")}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
