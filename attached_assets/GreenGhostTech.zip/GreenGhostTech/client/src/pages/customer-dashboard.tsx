import { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Download, Search, Pencil, Trash2 } from "lucide-react";
import { format, formatInTimeZone } from "date-fns-tz";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

interface Customer {
  id: number;
  email: string;
  address: string | null;
  lawn_area: number | null;
  subscription_quote: number | null;
  email_verified: boolean;
  created_at: string;
}

const editUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  address: z.string().min(1, "Address is required"),
  lawn_area: z.number().min(0, "Lawn area must be positive"),
  password: z.string().min(6, "Password must be at least 6 characters").optional(),
});

export default function CustomerDashboard() {
  const { toast } = useToast();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterVerified, setFilterVerified] = useState<"all" | "verified" | "unverified">("all");
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [_, setLocation] = useLocation();

  const form = useForm({
    resolver: zodResolver(editUserSchema),
    defaultValues: {
      email: "",
      address: "",
      lawn_area: 0,
      password: "",
    },
  });

  useEffect(() => {
    if (editingCustomer) {
      form.reset({
        email: editingCustomer.email,
        address: editingCustomer.address || "",
        lawn_area: editingCustomer.lawn_area || 0,
        password: "",
      });
    }
  }, [editingCustomer, form]);

  useEffect(() => {
    fetch("/api/user", { credentials: "include" })
      .then(async (response) => {
        if (!response.ok) {
          throw new Error("Not authenticated");
        }
        const user = await response.json();
        if (!user.isAdmin) {
          throw new Error("Not authorized");
        }
        return fetchCustomers();
      })
      .catch((error) => {
        console.error("Auth error:", error);
        toast({
          title: "Access Denied",
          description: "Please login as an administrator",
          variant: "destructive",
        });
        setLocation("/admin/login");
      });
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch("/api/customers", {
        credentials: "include"
      });
      if (!response.ok) throw new Error("Failed to fetch customers");
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error("Error fetching customers:", error);
      toast({
        title: "Error",
        description: "Failed to fetch customers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCustomer = async (customerId: number) => {
    if (!confirm("Are you sure you want to delete this customer?")) return;

    try {
      const response = await fetch(`/api/customers/${customerId}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (!response.ok) throw new Error("Failed to delete customer");

      toast({
        title: "Success",
        description: "Customer deleted successfully",
      });

      await fetchCustomers();
    } catch (error) {
      console.error("Error deleting customer:", error);
      toast({
        title: "Error",
        description: "Failed to delete customer",
        variant: "destructive",
      });
    }
  };

  const handleEditCustomer = async (data: z.infer<typeof editUserSchema>) => {
    if (!editingCustomer) return;

    try {
      const response = await fetch(`/api/customers/${editingCustomer.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });

      if (!response.ok) throw new Error("Failed to update customer");

      toast({
        title: "Success",
        description: "Customer updated successfully",
      });

      setIsEditDialogOpen(false);
      await fetchCustomers();
    } catch (error) {
      console.error("Error updating customer:", error);
      toast({
        title: "Error",
        description: "Failed to update customer",
        variant: "destructive",
      });
    }
  };

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (customer.address && customer.address.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesVerified = filterVerified === "all" ? true :
      filterVerified === "verified" ? customer.email_verified :
      !customer.email_verified;

    return matchesSearch && matchesVerified;
  });

  const formatCreatedAt = (date: string) => {
    return formatInTimeZone(
      new Date(date),
      'America/Chicago',
      'MMM d, yyyy h:mm a (zzz)'
    );
  };

  const exportToCSV = () => {
    const headers = ["ID", "Email", "Address", "Lawn Area", "Quote", "Verified", "Created At (CT)"];
    const csvData = filteredCustomers.map(c => [
      c.id,
      c.email,
      c.address || "",
      c.lawn_area || "",
      c.subscription_quote || "",
      c.email_verified ? "Yes" : "No",
      formatCreatedAt(c.created_at)
    ]);

    const csvContent = [
      headers.join(","),
      ...csvData.map(row => row.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `customers-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Customer Management</h1>
          <Button onClick={exportToCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export to CSV
          </Button>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by email or address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select
            value={filterVerified}
            onValueChange={(value: "all" | "verified" | "unverified") => setFilterVerified(value)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Customers</SelectItem>
              <SelectItem value="verified">Verified Only</SelectItem>
              <SelectItem value="unverified">Unverified Only</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Lawn Area (sq ft)</TableHead>
                <TableHead>Quote ($)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created (CT)</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">
                    Loading customers...
                  </TableCell>
                </TableRow>
              ) : filteredCustomers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">
                    No customers found
                  </TableCell>
                </TableRow>
              ) : (
                filteredCustomers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell>{customer.id}</TableCell>
                    <TableCell>{customer.email}</TableCell>
                    <TableCell>{customer.address || "—"}</TableCell>
                    <TableCell>
                      {typeof customer.lawn_area === 'number'
                        ? customer.lawn_area.toFixed(2)
                        : "—"}
                    </TableCell>
                    <TableCell>
                      {typeof customer.subscription_quote === 'number'
                        ? customer.subscription_quote.toFixed(2)
                        : "—"}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        customer.email_verified
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}>
                        {customer.email_verified ? "Verified" : "Pending"}
                      </span>
                    </TableCell>
                    <TableCell>{formatCreatedAt(customer.created_at)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingCustomer(customer);
                            setIsEditDialogOpen(true);
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteCustomer(customer.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Customer</DialogTitle>
              <DialogDescription>
                Update customer information or change their password.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleEditCustomer)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lawn_area"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Lawn Area (sq ft)</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="number"
                          onChange={e => field.onChange(parseFloat(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>New Password (optional)</FormLabel>
                      <FormControl>
                        <Input {...field} type="password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Save Changes</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}