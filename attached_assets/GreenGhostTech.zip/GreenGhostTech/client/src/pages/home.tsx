import HeroSection from "@/components/hero-section";
import ServiceCards from "@/components/service-cards";
import PricingSection from "@/components/pricing-section";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <HeroSection />
        <ServiceCards />
        <PricingSection />
      </main>
    </div>
  );
}
