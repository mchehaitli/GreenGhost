import BookingForm from "@/components/booking-form";

export default function Booking() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container px-4 mx-auto">
        <h1 className="text-4xl font-bold mb-8">Schedule Your Service</h1>
        <BookingForm />
      </div>
    </div>
  );
}
