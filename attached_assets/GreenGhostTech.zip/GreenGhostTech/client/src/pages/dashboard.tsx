import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useUser } from "@/hooks/use-user";
import { format } from "date-fns";
import { CalendarPlus, Clock, MapPin, Phone, Mail, History } from "lucide-react";
import { Link } from "wouter";
import MaintenanceTimeline from "@/components/maintenance-timeline";

interface Booking {
  id: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceDate: string;
  address: string;
  notes?: string;
  createdAt: string;
  status: 'completed' | 'scheduled' | 'missed';
}

export default function Dashboard() {
  const { user } = useUser();
  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
    enabled: !!user,
  });

  // Convert bookings to maintenance events
  const maintenanceEvents = bookings?.map(booking => ({
    id: booking.id,
    serviceDate: booking.serviceDate,
    status: booking.status || 'scheduled',
    description: `Lawn maintenance service at ${booking.address}`,
  })) || [];

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container px-4 mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold">
              Welcome back{user?.email ? `, ${user.email.split('@')[0]}` : ''}!
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage your lawn care services and view your maintenance history
            </p>
          </div>
          <Link href="/book">
            <Button className="gap-2">
              <CalendarPlus className="h-4 w-4" />
              Book Service
            </Button>
          </Link>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Maintenance Timeline Section */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <History className="h-5 w-5" />
                Maintenance Timeline
              </h2>
            </div>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Clock className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : maintenanceEvents.length > 0 ? (
              <MaintenanceTimeline events={maintenanceEvents} />
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No maintenance history yet</p>
                  <Link href="/book">
                    <Button className="mt-4">Schedule Your First Service</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Upcoming Bookings Section */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Upcoming Bookings</h2>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Clock className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : bookings?.length ? (
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <Card key={booking.id}>
                    <CardHeader>
                      <CardTitle>
                        Service on {format(new Date(booking.serviceDate), "PPP")}
                      </CardTitle>
                      <CardDescription>
                        {format(new Date(booking.serviceDate), "p")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{booking.address}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{booking.customerPhone}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span>{booking.customerEmail}</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        View Details
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No upcoming bookings</p>
                  <Link href="/book">
                    <Button className="mt-4">Book Now</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}