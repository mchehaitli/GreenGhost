import ChatInterface from "@/components/chat-interface";

export default function SupportPage() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6">Customer Support</h1>
        <p className="text-muted-foreground mb-8">
          Chat with our AI assistant for immediate help with your lawn care needs.
          For complex issues, our human support team will follow up within 24 hours.
        </p>
        <ChatInterface />
      </div>
    </div>
  );
}
