import { useForm } from "react-hook-form";
import { useUser } from "@/hooks/use-user";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { InputOTP } from "@/components/ui/input-otp";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import type { InsertUser } from "@db/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useState, useCallback } from "react";
import LawnMapper from "@/components/lawn-mapper";
import { AddressInput } from "@/components/address-input";

// Form schema that matches InsertUser type
const formSchema = z.object({
  email: z.string().min(1, "Email is required").email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  address: z.string().min(5, "Please enter a valid address").optional(),
  lawnArea: z.number().positive("Lawn area must be greater than 0").optional(),
});

type FormData = z.infer<typeof formSchema>;

enum RegistrationStep {
  Credentials,
  Verification,
  Address,
  LawnArea,
  Quote
}

export default function AuthPage() {
  const { toast } = useToast();
  const { login, register } = useUser();
  const [registrationStep, setRegistrationStep] = useState<RegistrationStep>(RegistrationStep.Credentials);
  const [calculatedQuote, setCalculatedQuote] = useState<number | null>(null);
  const [verificationEmail, setVerificationEmail] = useState<string>("");
  const [verificationCode, setVerificationCode] = useState<string>("");
  const [receivedCode, setReceivedCode] = useState<string>("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const registerForm = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
      address: '',
      lawnArea: 0,
    },
    mode: 'onBlur',
  });

  const loginForm = useForm<FormData>({
    resolver: zodResolver(formSchema.pick({ 
      email: true, 
      password: true 
    })),
    defaultValues: {
      email: '',
      password: ''
    },
    mode: 'onBlur',
  });

  const handleNextStep = useCallback(async () => {
    if (isLoading) return;

    try {
      setIsLoading(true);
      const formValues = registerForm.getValues();

      if (registrationStep === RegistrationStep.Credentials) {
        const email = formValues.email;
        try {
          const response = await fetch('/api/auth/request-verification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || "Failed to send verification code");
          }

          const data = await response.json();
          setVerificationEmail(email);
          if (data.code) {
            setReceivedCode(data.code);
          }

          toast({
            title: "Verification Code Sent",
            description: data.code 
              ? `Development mode: Your code is ${data.code}` 
              : "Please check your email for the verification code.",
          });
        } catch (error: any) {
          console.error('Verification request error:', error);
          toast({
            title: "Error",
            description: error.message || "Failed to send verification code",
            variant: "destructive",
          });
          return;
        }
      } else if (registrationStep === RegistrationStep.LawnArea) {
        const lawnArea = formValues.lawnArea;
        if (!lawnArea || isNaN(lawnArea) || lawnArea <= 0) {
          toast({
            title: "Error",
            description: "Please specify a valid lawn area",
            variant: "destructive",
          });
          return;
        }

        // Simple quote calculation
        const quote = lawnArea * 0.10;
        setCalculatedQuote(quote);
      }

      setRegistrationStep(prev => prev + 1);
    } catch (error: any) {
      console.error("Step progression error:", error);
      toast({
        title: "Error",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [registrationStep, isLoading, registerForm, toast, setRegistrationStep]);

  const handleSubmit = async (type: "login" | "register", data: FormData) => {
    if (isLoading) return;

    try {
      setIsLoading(true);

      // Validate required fields for registration
      if (type === "register") {
        if (!data.address) {
          throw new Error("Service address is required");
        }
        if (!data.lawnArea || data.lawnArea <= 0) {
          throw new Error("Valid lawn area is required");
        }
        if (!calculatedQuote || calculatedQuote <= 0) {
          throw new Error("Subscription quote calculation failed");
        }
      }

      // Format data properly for the API
      const formData: InsertUser = {
        email: data.email.trim(),
        password: data.password,
        address: data.address?.trim(),
        lawnArea: data.lawnArea ? Number(data.lawnArea) : undefined,
        subscriptionQuote: calculatedQuote ? Number(calculatedQuote) : undefined,
      };

      // This is where the data is sent to /api/register
      const result = type === "register" 
        ? await register(formData)  // Uses the useUser hook to make the API call
        : await login(formData);

      if (!result.ok) {
        throw new Error(result.message);
      }

      // On success, show a success message before redirecting
      toast({
        title: type === "login" ? "Login Successful" : "Registration Successful",
        description: "Redirecting to dashboard...",
      });

      // Short delay before redirect to show the success message
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1500);
    } catch (error: any) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to process request",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderRegistrationStep = () => {
    switch (registrationStep) {
      case RegistrationStep.Credentials:
        return (
          <div className="space-y-4">
            <FormField
              control={registerForm.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      {...field} 
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={registerForm.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <div className="relative">
                    <FormControl>
                      <Input
                        type={showRegisterPassword ? "text" : "password"}
                        {...field}
                        disabled={isLoading}
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                      disabled={isLoading}
                    >
                      {showRegisterPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
              type="button" 
              onClick={handleNextStep} 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                "Next"
              )}
            </Button>
          </div>
        );

      case RegistrationStep.Verification:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">Verify Your Email</h3>
              <p className="text-sm text-muted-foreground">
                We sent a verification code to {verificationEmail}
              </p>
              {receivedCode && (
                <p className="text-sm text-muted-foreground">
                  Development mode: Your code is <strong>{receivedCode}</strong>
                </p>
              )}
            </div>
            <div className="space-y-2">
              <FormLabel>Verification Code</FormLabel>
              <InputOTP
                maxLength={4}
                value={verificationCode}
                onChange={setVerificationCode}
                disabled={isLoading}
              />
              {!verificationCode.match(/^\d{4}$/) && verificationCode.length > 0 && (
                <p className="text-sm text-destructive">Please enter a valid 4-digit code</p>
              )}
            </div>
            <Button
              type="button"
              onClick={async () => {
                if (isLoading) return;

                try {
                  setIsLoading(true);
                  const response = await fetch('/api/auth/verify-code', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      email: verificationEmail,
                      code: verificationCode,
                    }),
                  });

                  if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || "Invalid verification code");
                  }

                  handleNextStep();
                } catch (error: any) {
                  toast({
                    title: "Verification Error",
                    description: error.message || "Failed to verify code",
                    variant: "destructive",
                  });
                } finally {
                  setIsLoading(false);
                }
              }}
              className="w-full"
              disabled={!verificationCode.match(/^\d{4}$/) || isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Verify"
              )}
            </Button>
          </div>
        );

      case RegistrationStep.Address:
        return (
          <div className="space-y-4">
            <FormField
              control={registerForm.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Address</FormLabel>
                  <FormControl>
                    <AddressInput
                      value={field.value}
                      onChange={(value, isValid) => {
                        field.onChange(value);
                        if (isValid) {
                          handleNextStep();
                        }
                      }}
                      placeholder="Enter your service address"
                      className="w-full"
                      disabled={isLoading}
                      name={field.name}
                      onBlur={field.onBlur}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );

      case RegistrationStep.LawnArea:
        return (
          <div className="space-y-4">
            <LawnMapper
              onAreaChange={(area) => {
                registerForm.setValue('lawnArea', area);
              }}
            />
            <Button 
              type="button" 
              onClick={handleNextStep} 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Calculating...
                </>
              ) : (
                "Get Quote"
              )}
            </Button>
          </div>
        );

      case RegistrationStep.Quote:
        return (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">Monthly Service Quote</h3>
              <p className="text-2xl font-bold">${calculatedQuote?.toFixed(2)}</p>
              <p className="text-sm text-muted-foreground mt-2">
                Based on your lawn area of {registerForm.getValues('lawnArea')} sq ft
              </p>
            </div>
            <Button
              type="button"
              className="w-full"
              onClick={() => handleSubmit("register", registerForm.getValues())}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Completing Registration...
                </>
              ) : (
                "Complete Registration"
              )}
            </Button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 flex items-center justify-center">
      <Card className="w-[400px]">
        <CardHeader>
          <CardTitle>Welcome to Green Ghost</CardTitle>
          <CardDescription>
            Login or create an account to manage your lawn care services
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <Form {...loginForm}>
                <form
                  onSubmit={loginForm.handleSubmit((data) =>
                    handleSubmit("login", data)
                  )}
                  className="space-y-4"
                >
                  <FormField
                    control={loginForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} disabled={isLoading} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <div className="relative">
                          <FormControl>
                            <Input
                              type={showLoginPassword ? "text" : "password"}
                              {...field}
                              disabled={isLoading}
                            />
                          </FormControl>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                            onClick={() => setShowLoginPassword(!showLoginPassword)}
                            disabled={isLoading}
                          >
                            {showLoginPassword ? (
                              <EyeOff className="h-4 w-4 text-muted-foreground" />
                            ) : (
                              <Eye className="h-4 w-4 text-muted-foreground" />
                            )}
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Logging in...
                      </>
                    ) : (
                      "Login"
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>
            <TabsContent value="register">
              <Form {...registerForm}>
                {renderRegistrationStep()}
              </Form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}