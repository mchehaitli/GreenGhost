import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Apple, Smartphone } from "lucide-react";

export default function Download() {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container px-4 mx-auto">
        <h1 className="text-4xl font-bold mb-8 text-center">Download Our App</h1>
        <div className="max-w-3xl mx-auto">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Get the Green Ghost Mobile App</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                Take control of your lawn care on the go. Download our mobile app
                to schedule services, track your robotic mower, and manage your
                subscription from anywhere.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="gap-2"
                  onClick={() => window.open('https://apps.apple.com/app/green-ghost', '_blank')}
                >
                  <Apple className="h-5 w-5" />
                  Download for iOS
                </Button>
                <Button
                  size="lg"
                  className="gap-2"
                  onClick={() => window.open('https://play.google.com/store/apps/details?id=com.greenghostapp', '_blank')}
                >
                  <Smartphone className="h-5 w-5" />
                  Download for Android
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="p-6">
              <h3 className="font-bold mb-2">Schedule Services</h3>
              <p className="text-sm text-muted-foreground">
                Book and manage your lawn care services with just a few taps
              </p>
            </div>
            <div className="p-6">
              <h3 className="font-bold mb-2">Real-time Tracking</h3>
              <p className="text-sm text-muted-foreground">
                Monitor your robotic mower's progress in real-time
              </p>
            </div>
            <div className="p-6">
              <h3 className="font-bold mb-2">Instant Support</h3>
              <p className="text-sm text-muted-foreground">
                Get help instantly through our in-app support chat
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
