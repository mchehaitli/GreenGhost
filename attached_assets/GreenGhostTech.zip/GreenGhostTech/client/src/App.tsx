import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from "framer-motion";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Booking from "@/pages/booking";
import Download from "@/pages/download";
import NavigationBar from "@/components/navigation-bar";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import AdminLoginPage from "@/pages/admin-login";
import CustomerDashboard from "@/pages/customer-dashboard";
import { useUser } from "@/hooks/use-user";
import { Loader2 } from "lucide-react";
import PageTransition from "@/components/page-transition";

function PrivateRoute({ component: Component, ...rest }: any) {
  const { user, isLoading } = useUser();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  if (!user) {
    window.location.href = "/auth";
    return null;
  }

  return <Component {...rest} />;
}

function Router() {
  const [location] = useLocation();

  // Don't show navigation bar on admin pages
  const hideNavigation = location === "/admin/login" || location === "/customer-dashboard";

  return (
    <>
      {!hideNavigation && <NavigationBar />}
      <AnimatePresence mode="wait">
        <Switch location={location} key={location}>
          <Route 
            path="/" 
            component={() => (
              <PageTransition>
                <Home />
              </PageTransition>
            )} 
          />
          <Route 
            path="/book" 
            component={() => (
              <PageTransition>
                <Booking />
              </PageTransition>
            )} 
          />
          <Route 
            path="/download" 
            component={() => (
              <PageTransition>
                <Download />
              </PageTransition>
            )} 
          />
          <Route 
            path="/auth" 
            component={() => (
              <PageTransition>
                <AuthPage />
              </PageTransition>
            )} 
          />
          <Route 
            path="/admin/login" 
            component={() => (
              <PageTransition>
                <AdminLoginPage />
              </PageTransition>
            )} 
          />
          <Route 
            path="/customer-dashboard" 
            component={(props) => (
              <PageTransition>
                <CustomerDashboard {...props} />
              </PageTransition>
            )} 
          />
          <Route 
            path="/dashboard" 
            component={(props) => (
              <PageTransition>
                <PrivateRoute component={Dashboard} {...props} />
              </PageTransition>
            )} 
          />
          <Route 
            component={() => (
              <PageTransition>
                <NotFound />
              </PageTransition>
            )} 
          />
        </Switch>
      </AnimatePresence>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;